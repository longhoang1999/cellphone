$(document).ready(function(){
	$('.phone .title').hover(function(){
		$('.phone .title').css('background','#e11b1e');
		$('.phone .title a').css('color','white');
		$('.dienthoai').css('display','block');
	});
	$('.phone .title').mouseleave(function(){
		$('.phone .title').css('background','#eeeeee');
		$('.phone .title a').css('color','black');
		$('.dienthoai').css('display','none');
	});
	$('.dienthoai').mouseenter(function(){		
		$('.phone .title a').css('color','#e11b1e');
		$('.dienthoai').css('display','block');
	});
	$('.dienthoai').mouseleave(function(){
		$('.phone .title a').css('color','black');
		$('.dienthoai').css('display','none');
	});

	$('.tablet .title').hover(function(){
		$('.tablet .title').css('background','#e11b1e');
		$('.tablet .title a').css('color','white');
		$('.tablet-plus').css('display','block');
	});
	$('.tablet .title').mouseleave(function(){
		$('.tablet .title').css('background','#eeeeee');
		$('.tablet .title a').css('color','black');
		$('.tablet-plus').css('display','none');
	});
	$('.tablet-plus').mouseenter(function(){		
		$('.tablet .title a').css('color','#e11b1e');
		$('.tablet-plus').css('display','block');
	});
	$('.tablet').mouseleave(function(){
		$('.tablet .title a').css('color','black');
		$('.tablet-plus').css('display','none');
	});

	$('.phukien .title').hover(function(){
		$('.phukien .title').css('background','#e11b1e');
		$('.phukien .title a').css('color','white');
		$('.phukien-plus').css('display','block');
	});
	$('.phukien .title').mouseleave(function(){
		$('.phukien .title').css('background','#eeeeee');
		$('.phukien .title a').css('color','black');
		$('.phukien-plus').css('display','none');
	});
	$('.phukien-plus').mouseenter(function(){		
		$('.phukien .title a').css('color','#e11b1e');
		$('.phukien-plus').css('display','block');
	});
	$('.phukien').mouseleave(function(){
		$('.phukien .title a').css('color','black');
		$('.phukien-plus').css('display','none');
	});

	$('.dongho .title').hover(function(){
		$('.dongho .title').css('background','#e11b1e');
		$('.dongho .title a').css('color','white');
		$('.dongho-plus').css('display','block');
	});
	$('.dongho .title').mouseleave(function(){
		$('.dongho .title').css('background','#eeeeee');
		$('.dongho .title a').css('color','black');
		$('.dongho-plus').css('display','none');
	});
	$('.dongho-plus').mouseenter(function(){		
		$('.dongho .title a').css('color','#e11b1e');
		$('.dongho-plus').css('display','block');
	});
	$('.dongho').mouseleave(function(){
		$('.dongho .title a').css('color','black');
		$('.dongho-plus').css('display','none');
	});

	$('.amthanh .title').hover(function(){
		$('.amthanh .title').css('background','#e11b1e');
		$('.amthanh .title a').css('color','white');
		$('.amthanh-plus').css('display','block');
	});
	$('.amthanh .title').mouseleave(function(){
		$('.amthanh .title').css('background','#eeeeee');
		$('.amthanh .title a').css('color','black');
		$('.amthanh-plus').css('display','none');
	});
	$('.amthanh-plus').mouseenter(function(){		
		$('.amthanh .title a').css('color','#e11b1e');
		$('.amthanh-plus').css('display','block');
	});
	$('.amthanh').mouseleave(function(){
		$('.amthanh .title a').css('color','black');
		$('.amthanh-plus').css('display','none');
	});

	$('.laptop .title').hover(function(){
		$('.laptop .title').css('background','#e11b1e');
		$('.laptop .title a').css('color','white');
		$('.laptop-plus').css('display','block');
	});
	$('.laptop .title').mouseleave(function(){
		$('.laptop .title').css('background','#eeeeee');
		$('.laptop .title a').css('color','black');
		$('.laptop-plus').css('display','none');
	});
	$('.laptop-plus').mouseenter(function(){		
		$('.laptop .title a').css('color','#e11b1e');
		$('.laptop-plus').css('display','block');
	});
	$('.laptop').mouseleave(function(){
		$('.laptop .title a').css('color','black');
		$('.laptop-plus').css('display','none');
	});

	$('.simthe .title').hover(function(){
		$('.simthe .title').css('background','#e11b1e');
		$('.simthe .title a').css('color','white');
		$('.simthe-plus').css('display','block');
	});
	$('.simthe .title').mouseleave(function(){
		$('.simthe .title').css('background','#eeeeee');
		$('.simthe .title a').css('color','black');
		$('.simthe-plus').css('display','none');
	});
	$('.simthe-plus').mouseenter(function(){		
		$('.simthe .title a').css('color','#e11b1e');
		$('.simthe-plus').css('display','block');
	});
	$('.simthe').mouseleave(function(){
		$('.simthe .title a').css('color','black');
		$('.simthe-plus').css('display','none');
	});

	$('.hangcu .title').hover(function(){
		$('.hangcu .title').css('background','#e11b1e');
		$('.hangcu .title a').css('color','white');
		$('.hangcu-plus').css('display','block');
	});
	$('.hangcu .title').mouseleave(function(){
		$('.hangcu .title').css('background','#eeeeee');
		$('.hangcu .title a').css('color','black');
		$('.hangcu-plus').css('display','none');
	});
	$('.hangcu-plus').mouseenter(function(){		
		$('.hangcu .title a').css('color','#e11b1e');
		$('.hangcu-plus').css('display','block');
	});
	$('.hangcu').mouseleave(function(){
		$('.hangcu .title a').css('color','black');
		$('.hangcu-plus').css('display','none');
	});

	$('.tragop .title').hover(function(){
		$('.tragop .title').css('background','#e11b1e');
		$('.tragop .title a').css('color','white');		
	});
	$('.tragop .title').mouseleave(function(){
		$('.tragop .title').css('background','#eeeeee');
		$('.tragop .title a').css('color','black');	
	});


	$('.dichvu .title').hover(function(){
		$('.dichvu .title').css('background','#e11b1e');
		$('.dichvu .title a').css('color','white');		
	});
	$('.dichvu .title').mouseleave(function(){
		$('.dichvu .title').css('background','#eeeeee');
		$('.dichvu .title a').css('color','black');	
	});
	$('.doanhnghiep .title').hover(function(){
		$('.doanhnghiep .title').css('background','#e11b1e');
		$('.doanhnghiep .title a').css('color','white');		
	});
	$('.doanhnghiep .title').mouseleave(function(){
		$('.doanhnghiep .title').css('background','#eeeeee');
		$('.doanhnghiep .title a').css('color','black');	
	});
	$('.khuyenmai .title').hover(function(){
		$('.khuyenmai .title').css('background','#e11b1e');
		$('.khuyenmai .title a').css('color','white');		
	});
	$('.khuyenmai .title').mouseleave(function(){
		$('.khuyenmai .title').css('background','#eeeeee');
		$('.khuyenmai .title a').css('color','black');	
	});

	$('.congnghe .title').hover(function(){
		$('.congnghe .title').css('background','#e11b1e');
		$('.congnghe .title a').css('color','white');		
	});
	$('.congnghe .title').mouseleave(function(){
		$('.congnghe .title').css('background','#eeeeee');
		$('.congnghe .title a').css('color','black');	
	});
	
	$('#khuvuc').click(function(){
		$('.city').css('display','block');
		$('.HN').click(function(){
			$('#khuvuc').html('Hà Nội'+ ' ' +'<i class="fas fa-sort-down"></i>');
		});
		$('.HCM').click(function(){
			$('#khuvuc').html('Hồ Chí Minh'+'<i class="fas fa-sort-down"></i>');
		});

	});
	$('#khuvuc').hover(function(){
		$('#khuvuc').css('background','#e9e2e2');
	});
	$('#khuvuc').mouseleave(function(){
		$('#khuvuc').css('background','#cccccc');
	})


	$('.city').mouseenter(function(){
		$('city').css('display','block');
	});
	$('.city').mouseleave(function(){
		$('.city').css('display','none');
	});

	

	//slide Show
	var Kichthuoc=document.getElementsByClassName("slide")[0].clientWidth;
	var Img = $(".chuyen-slide img").length;
	var Max=Kichthuoc * Img;
	Max-=Kichthuoc;
	var Chuyen=0;
	function Next(){
		if(Chuyen<Max)
		{
			Chuyen+=Kichthuoc;
		}
		else{
			Chuyen=0;
		}	
		$('.chuyen-slide').css('margin-left','-'+Chuyen+'px');	
	}
	function Prev(){
		if(Chuyen==0)Chuyen=Max;
		else Chuyen-=Kichthuoc;
	
		$('.chuyen-slide').css('margin-left','-'+Chuyen+'px');
	}
	var slide1=setInterval(function(){
		Next();
	},3000);

	var n=2;
	var slide2=setInterval(function(){
		$('.slideShow .title li').css('background','white');
		$('.slideShow .title li').css('color','black');
		$('.order-'+n).css('background','#d70018');
		$('.order-'+n).css('color','white');
		n++;
		if(n>6)n=1;
	},3000);

	
	var Kt=document.getElementById("slide-sale").clientWidth;
	var ul = $(".noidung ul").length;
	var Maxsale=Kt * ul;
	Maxsale-=Kt;
	var Chuyensale=0;
	function Nextsale(){
		if(Chuyensale<Maxsale)
		{
			Chuyensale+=Kt;
		}
		else{
			Chuyensale=0;
		}	
		$('.noidung').css('margin-left','-'+Chuyensale+'px');	
	};
	function Prevsale(){
		if(Chuyensale==0)Chuyensale=Maxsale;
		else Chuyensale-=Kt;
	
		$('.noidung').css('margin-left','-'+Chuyensale+'px');
	};

	$('#Nextsale').click(function(){
		Nextsale();
	});
	
	$('#Prevsale').click(function(){
		Prevsale();
	});

	
	$('.Dienthoai .khoi1').click(function(){
		$('.Dienthoai .khoi1').toggle(function(){
			$('.Dienthoai .khoi2 ul').css('margin-left',0+'px');	
		});
	});
	$('.Dongho .khoi1').click(function(){
		$('.Dongho .khoi1').toggle(function(){
			$('.Dongho .khoi2 ul').css('margin-left',0+'px');	
		});
	});
	$('.Amthanh .khoi1').click(function(){
		$('.Amthanh .khoi1').toggle(function(){
			$('.Amthanh .khoi2 ul').css('margin-left',0+'px');	
		});
	});
	$('.Laptop .khoi1').click(function(){
		$('.Laptop .khoi1').toggle(function(){
			$('.Laptop .khoi2 ul').css('margin-left',0+'px');	
		});
	});
	$('.Phukien .khoi1').click(function(){
		$('.Phukien .khoi1').toggle(function(){
			$('.Phukien .khoi2 ul').css('margin-left',0+'px');	
		});
	});
	$('.Hangcu .khoi1').click(function(){
		$('.Hangcu .khoi1').toggle(function(){
			$('.Hangcu .khoi2 ul').css('margin-left',0+'px');	
		});
	});

	window.onscroll = function() {scrollFunction()};
	function scrollFunction() {
  		if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    		$(".BachtoTop").css("display","block");
  		} else {
    		$(".BachtoTop").css("display","none");
  		}
	};
	$('.BachtoTop').click(function(){
		$('body,html').animate({
				scrollTop: 0
		})
	});
});