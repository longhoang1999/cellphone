$(document).ready(function(){
	// $('.title-1').click(function(){
	// 	$('.main-content').css('display','block');
	// 	$('.main-content-second').css('display','none');
	// 	$('.title-1').css('border-bottom-width','0');
	// 	$('.title-2').css('border-bottom','1px solid #d0d0d0');
	// });
	// $('.title-2').click(function(){
	// 	$('.main-content').css('display','none');
	// 	$('.main-content-second').css('display','block');
	// 	$('.title-2').css('border-bottom-width','0');
	// 	$('.title-1').css('border-bottom','1px solid #d0d0d0');
	// });
	$('.delete').click(function(){
		alert('bạn có muốn xóa không');
	});
});